document.getElementById("testForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let total = 0;
    const respuestas = document.querySelectorAll("input[type='radio']:checked");

    if (respuestas.length !== 4) {
        alert("Por favor responde todas las preguntas.");
        return;
    }

    respuestas.forEach(r => {
        total += parseInt(r.value);
    });

    let nivel = "";
    if (total <= 10) nivel = "Bajo";
    else if (total <= 17) nivel = "Medio";
    else nivel = "Alto";

    localStorage.setItem("resultadoEmpatia", nivel);
    window.location.href = "resultado.html";
});